﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pepper.MINT_Menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Inject_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cdn.discordapp.com/attachments/1305265773337510044/1305582250045472890/Overpowered_Mod_Menu_1.unitypackage?ex=67338db8&is=67323c38&hm=a56e2a5ef0b43453961aadd4a762623b2e69c1a90f7bee4abcc717bc08822f63&");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.WindowState = FormWindowState.Maximized;
        }
    }
}
